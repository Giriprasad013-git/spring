package org.alvas.service;

import org.alvas.dao.StudentDao;
import org.alvas.dto.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentService {
	@Autowired
	StudentDao dao;

	public Student saveStudent(Student student) {

		if (student.getId() > 100) {
			return dao.saveStudent(student);
		} else {
			System.out.println("you should provide id greater than 100");
			return null;
		}

	}

}
