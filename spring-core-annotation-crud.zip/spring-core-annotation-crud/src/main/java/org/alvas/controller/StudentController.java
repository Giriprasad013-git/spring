package org.alvas.controller;

import org.alvas.dto.Student;
import org.alvas.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class StudentController {
	
	public static void main(String[] args) {
	
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext();
		Student student  = (Student) applicationContext.getBean("myStudent");
		StudentService student1 = (StudentService) applicationContext.getBean("mystudent");
		student.setId(101);
		student.setName("Giriprasad");
		student.setEmail("giriprasadpatil42@gmail.com");
		student1.saveStudent(student);
	}

}
