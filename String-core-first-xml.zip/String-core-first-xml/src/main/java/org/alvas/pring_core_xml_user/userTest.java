package org.alvas.pring_core_xml_user;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class userTest {
	public static void main(String[] args) {
		ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("contructor-injection.xml");
		User user= (User) applicationContext.getBean("myUser");
		
		System.out.println(user.id);
		System.out.println(user.name);
		
	}
}
