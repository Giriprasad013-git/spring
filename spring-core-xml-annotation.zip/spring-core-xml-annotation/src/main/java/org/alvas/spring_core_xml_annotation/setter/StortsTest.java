package org.alvas.spring_core_xml_annotation.setter;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StortsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConfigurableApplicationContext applicationContext = new ClassPathXmlApplicationContext("annotation.xml");
		Sports sports = (Sports) applicationContext.getBean("mySports");
		System.out.println(sports.getName());
	}

}
