package org.alvas.spring_core_xml_annotation.ref.objects;

import org.springframework.stereotype.Component;

@Component
public class Branch {

	public void getBranch() {
		System.out.println("CSE");
	}	
}
