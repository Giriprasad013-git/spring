package org.alvas.spring_core_xml_annotation.contructor;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component(value = "myCustomer")
public class Customer {
	int id;
	String name;
	public Customer(@Value(value = "435")  int id,@Value(value="Giriprasad") String name) {
		this.id = id;
		this.name = name;
	}
	
	public void print() {
		System.out.println(id);
		System.out.println(name);
	}
}
