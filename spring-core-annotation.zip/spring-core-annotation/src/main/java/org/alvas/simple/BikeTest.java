package org.alvas.simple;

import org.alvas.myConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class BikeTest {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(myConfig.class);
		Bike bike = (Bike) applicationContext.getBean("myBike");
		bike.getBike();
	}
}
